/**
 * \file XXXXXTest.cpp
 * \brief Implementation for testing XXXX
 * \date XX/XX/XX
 */

#include <cppunit/config/SourcePrefix.h>
#include "SampleTest.h"


CPPUNIT_TEST_SUITE_REGISTRATION( cSampleTest );


cSampleTest::cSampleTest()
{
}

cSampleTest::~cSampleTest()
{
}


void cSampleTest::setUp()
{
}

void cSampleTest::tearDown()
{
}


/*! Do the tests
 */
void cSampleTest::test()
{
	CPPUNIT_ASSERT( (2*2) == 4 );
}
